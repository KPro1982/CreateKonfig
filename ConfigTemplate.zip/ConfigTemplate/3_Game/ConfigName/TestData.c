class TestData
{
	string dataString;
}